import battle.BattleAI;
import battle.BattleManager;
import battle.Side;
import model.PokemonFactory;
import model.Team;
import ui.BattleScreen;
import ui.MainMenu;
import ui.RoundedButton;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicReference;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 * Tests the real UI panels WITHOUT opening a window (works on machines with no display):
 * screens are laid out and painted into images, and buttons/cards are triggered with real events.
 * Not covered here: the JFrame itself and the JDialog used for switching (they need a display).
 *
 * Run:  java -Djava.awt.headless=true -cp out GuiHeadlessTest shots
 */
public class GuiHeadlessTest {

    static File shotDir;
    static int failures = 0;

    static void check(String name, boolean ok) {
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name);
        if (!ok) failures++;
    }

    // ---------- helpers ----------

    static <T> T edt(Callable<T> job) throws Exception {
        if (SwingUtilities.isEventDispatchThread()) {
            return job.call(); // already on the event thread (nested helper call)
        }
        AtomicReference<T> box = new AtomicReference<>();
        SwingUtilities.invokeAndWait(() -> {
            try { box.set(job.call()); } catch (Exception e) { throw new RuntimeException(e); }
        });
        return box.get();
    }

    static void layoutTree(Component c) {
        if (c instanceof Container) {
            ((Container) c).doLayout();
            for (Component child : ((Container) c).getComponents()) layoutTree(child);
        }
    }

    static void shot(JComponent c, String name) throws Exception {
        edt(() -> {
            c.setSize(1120, 800);
            layoutTree(c);
            BufferedImage img = new BufferedImage(1120, 800, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = img.createGraphics();
            c.print(g);
            g.dispose();
            ImageIO.write(img, "png", new File(shotDir, name + ".png"));
            return null;
        });
    }

    static List<Component> all(Container root) {
        List<Component> out = new ArrayList<>();
        for (Component c : root.getComponents()) {
            out.add(c);
            if (c instanceof Container) out.addAll(all((Container) c));
        }
        return out;
    }

    static RoundedButton button(Container root, String startsWith) throws Exception {
        return edt(() -> {
            for (Component c : all(root)) {
                if (c instanceof RoundedButton && ((RoundedButton) c).getMainLabel().startsWith(startsWith)) {
                    return (RoundedButton) c;
                }
            }
            return null;
        });
    }

    static void click(RoundedButton b) throws Exception {
        edt(() -> { b.doClick(0); return null; });
    }

    static String turnText(Container root) throws Exception {
        return edt(() -> {
            for (Component c : all(root)) {
                if (c instanceof JLabel) {
                    String t = ((JLabel) c).getText();
                    if (t != null && (t.startsWith("YOUR TURN") || t.startsWith("OPPONENT'S") || t.startsWith("YOU WIN")
                            || t.startsWith("YOU LOST") || t.startsWith("Choose your next"))) return t;
                }
            }
            return "";
        });
    }

    static String screenName(MainMenu menu) throws Exception {
        return edt(() -> menu.getComponent(0).getClass().getSimpleName());
    }

    static boolean waitFor(Callable<Boolean> condition, int ms) throws Exception {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            if (edt(condition)) return true;
            Thread.sleep(50);
        }
        return false;
    }

    /** Clicks Special if it is enabled, otherwise Normal Attack, until the battle ends. Returns the number of clicks. */
    static int playUntil(Container screen, Callable<Boolean> finished, int timeoutMs, Runnable midShot) throws Exception {
        int clicks = 0;
        long end = System.currentTimeMillis() + timeoutMs;
        while (!edt(finished) && System.currentTimeMillis() < end) {
            RoundedButton pick = edt(() -> {
                RoundedButton normal = null;
                for (Component c : all(screen)) {
                    if (c instanceof RoundedButton && c.isEnabled()) {
                        String l = ((RoundedButton) c).getMainLabel();
                        if (l.equals("Normal Attack")) normal = (RoundedButton) c;
                        else if (!l.equals("Block") && !l.equals("Switch")) return (RoundedButton) c; // the special move
                    }
                }
                return normal;
            });
            if (pick != null) {
                click(pick);
                clicks++;
                if (clicks == 3 && midShot != null) midShot.run();
            }
            Thread.sleep(40);
        }
        return clicks;
    }

    // ---------- tests ----------

    public static void main(String[] args) throws Exception {
        shotDir = new File(args.length > 0 ? args[0] : "shots");
        shotDir.mkdirs();

        battleScreen3v3();
        blockIndicator();
        menuNavigation();

        System.out.println(failures == 0 ? "\nGUI HEADLESS TEST: ALL PASSED" : "\nGUI HEADLESS TEST: " + failures + " FAILED");
        System.exit(failures == 0 ? 0 : 1);
    }

    /** A 3v3 battle played through the real BattleScreen buttons, including voluntary and forced switches. */
    static void battleScreen3v3() throws Exception {
        System.out.println("BattleScreen, 3v3 team battle");
        List<String> picks = List.of("Charizard", "Pikachu", "Gengar");
        Random rng = new Random(11);
        BattleManager battle = new BattleManager(PokemonFactory.createTeam(picks),
                PokemonFactory.createOpponentTeam(picks, rng), new BattleAI(rng));

        AtomicReference<Boolean> result = new AtomicReference<>();
        int[] forcedPrompts = {0};
        int[] voluntaryPrompts = {0};

        BattleScreen[] holder = new BattleScreen[1];
        edt(() -> {
            holder[0] = new BattleScreen(battle, result::set, 40) {
                @Override
                protected int chooseSwitchTarget(boolean forced) {
                    Team t = battle.getPlayerTeam();
                    if (forced) {
                        forcedPrompts[0]++;
                        try { shot(this, "5-forced-replacement"); } catch (Exception e) { throw new RuntimeException(e); }
                    } else {
                        voluntaryPrompts[0]++;
                    }
                    for (int i = 0; i < t.size(); i++) if (t.canSwitchTo(i)) return i;
                    return -1;
                }
            };
            return null;
        });
        BattleScreen screen = holder[0];
        shot(screen, "3-battle-start");

        String t0 = turnText(screen);
        check("turn indicator is shown at the start (" + t0 + ")", t0.startsWith("YOUR TURN") || t0.startsWith("OPPONENT"));
        boolean playerFirst = t0.startsWith("YOUR TURN");
        if (!playerFirst) {
            check("opponent moves first automatically and hands the turn back",
                    waitFor(() -> turnText(screen).startsWith("YOUR TURN"), 3000));
        }
        RoundedButton normal = button(screen, "Normal Attack");
        RoundedButton special = button(screen, "Flamethrower");
        check("player buttons are enabled on the player's turn", normal.isEnabled() && special.isEnabled() && button(screen, "Block").isEnabled());
        check("special button shows its unique move name", special != null);

        int oppHpBefore = battle.getOpponentTeam().getActive().getCurrentHp();
        click(special);
        check("special click hit the opponent", battle.getOpponentTeam().getActive().getCurrentHp() < oppHpBefore
                || battle.getOpponentTeam().getActive() != battle.getOpponentTeam().getMembers().get(0));
        String afterClick = turnText(screen);
        check("buttons lock during the opponent's turn", afterClick.startsWith("OPPONENT")
                && !button(screen, "Normal Attack").isEnabled() && !button(screen, "Flamethrower").isEnabled());
        check("opponent takes its turn by itself", waitFor(() -> turnText(screen).startsWith("YOUR TURN")
                || battle.isBattleOver(), 3000));
        shot(screen, "4-battle-after-special");

        RoundedButton sp2 = button(screen, "Flamethrower");
        check("special is disabled and shows its cooldown",
                !sp2.isEnabled() && sp2.getSubLabel().startsWith("Cooldown: 2"));
        check("clicking the disabled special changes nothing", edt(() -> {
            int before = battle.getTurnNumber();
            sp2.doClick(0);
            return battle.getTurnNumber() == before;
        }));

        // Voluntary switch through the Switch button.
        RoundedButton sw = button(screen, "Switch");
        check("switch is enabled in a team battle", sw.isEnabled());
        click(sw);
        check("switch button opened the chooser and used the turn",
                voluntaryPrompts[0] == 1 && battle.getPlayerTeam().getActiveIndex() != 0);

        playUntil(screen, () -> result.get() != null, 120_000, () -> {
            try { shot(screen, "4b-battle-mid"); } catch (Exception e) { throw new RuntimeException(e); }
        });
        boolean playerWon = battle.getWinner() == Side.PLAYER;
        check("battle finished and reported the correct result to its host", result.get() != null && result.get() == playerWon);
        int faintedMine = 0;
        for (model.Pokemon p : battle.getPlayerTeam().getMembers()) if (p.isFainted()) faintedMine++;
        int expectedPrompts = faintedMine - (playerWon ? 0 : 1); // the last faint ends the battle: no replacement
        check("forced-replacement chooser opened exactly once per non-final faint (" + forcedPrompts[0] + ")",
                forcedPrompts[0] == expectedPrompts);
        check("all buttons disabled after the battle ended",
                !button(screen, "Normal Attack").isEnabled() && !button(screen, "Block").isEnabled()
                        && !button(screen, "Switch").isEnabled());
        shot(screen, "6-battle-over");
    }

    /** Blocking shows a clear SHIELD UP indicator, halves the next hit, then the indicator goes away. */
    static void blockIndicator() throws Exception {
        System.out.println("Block indicator");
        Random rng = new Random(2);
        // Gengar (speed 110) always moves first against Snorlax (speed 30).
        BattleManager battle = new BattleManager(PokemonFactory.createTeam(List.of("Gengar")),
                PokemonFactory.createTeam(List.of("Snorlax")), new BattleAI(rng));
        BattleScreen screen = edt(() -> new BattleScreen(battle, won -> { }, 700));

        check("no shield badge before blocking", shieldBadges(screen) == 0);
        click(button(screen, "Block"));
        check("SHIELD UP badge is visible after clicking Block", shieldBadges(screen) == 1);
        check("Block button becomes disabled (not twice in a row) during the opponent's turn", !button(screen, "Block").isEnabled());
        shot(screen, "9-blocking");

        int hpBefore = battle.getPlayerTeam().getActive().getCurrentHp();
        check("opponent hit is applied after its delay", waitFor(() -> battle.getPlayerTeam().getActive().getCurrentHp() < hpBefore, 3000));
        int taken = hpBefore - battle.getPlayerTeam().getActive().getCurrentHp();
        model.Pokemon attacker = battle.getOpponentTeam().getActive();
        model.Pokemon defender = battle.getPlayerTeam().getActive();
        // The AI picked either its normal or its special attack; the block must have halved whichever it was.
        int halvedNormal = BattleManager.applyBlock(BattleManager.calculateDamage(attacker, defender, attacker.getNormalAttack()));
        int halvedSpecial = BattleManager.applyBlock(BattleManager.calculateDamage(attacker, defender, attacker.getSpecialAttack()));
        check("damage taken while blocking was exactly halved (took " + taken + ")",
                taken == halvedNormal || taken == halvedSpecial);
        check("SHIELD UP badge disappears once the block is used up", waitFor(() -> shieldBadges(screen) == 0, 2000));
        check("player's turn again", waitFor(() -> turnText(screen).startsWith("YOUR TURN"), 2000));
    }

    static int shieldBadges(Container root) throws Exception {
        return edt(() -> {
            int n = 0;
            for (Component c : all(root)) {
                if (c instanceof ui.Badge && c.isVisible() && ((ui.Badge) c).getText().equals("SHIELD UP")) n++;
            }
            return n;
        });
    }

    /** Title -> selection -> 1v1 battle -> result -> rematch -> new team -> main menu, all via real clicks. */
    static void menuNavigation() throws Exception {
        System.out.println("MainMenu navigation (1v1)");
        boolean[] quit = {false};
        MainMenu menu = edt(() -> new MainMenu(() -> quit[0] = true));
        shot(menu, "1-title");
        check("starts on the title screen", screenName(menu).equals("TitlePanel"));

        click(button(menu, "Start Battle"));
        check("Start Battle opens the selection screen", screenName(menu).equals("PokemonSelectionScreen"));
        shot(menu, "2a-selection-empty");
        check("start is disabled until a pick is made", !button(menu, "Pick a").isEnabled());

        List<Component> cards = edt(() -> {
            List<Component> out = new ArrayList<>();
            for (Component c : all(menu)) if (c.getClass().getSimpleName().equals("RosterCard")) out.add(c);
            return out;
        });
        check("8 roster cards are shown", cards.size() == 8);

        // pick Charizard, Pikachu, Gengar, then try a 4th (must be refused)
        for (int i : new int[] {1, 0, 5, 7}) clickCard(cards.get(i));
        shot(menu, "2b-selection-three-picked");
        check("three picks are accepted, a fourth is refused",
                button(menu, "Start Team Battle (3v3)") != null && button(menu, "Start Team Battle (3v3)").isEnabled());
        // un-pick two of them -> back to a single pick
        clickCard(cards.get(0));
        clickCard(cards.get(5));
        check("clicking a picked card removes it", button(menu, "Start Battle (1v1)") != null);
        // swap the lead: remove Charizard, pick Squirtle
        clickCard(cards.get(1));
        clickCard(cards.get(3));
        RoundedButton start1v1 = button(menu, "Start Battle (1v1)");
        check("single pick enables the 1v1 start button", start1v1 != null && start1v1.isEnabled());
        click(start1v1);
        check("battle screen opens", screenName(menu).equals("BattleScreen"));

        Container battleScreen1 = edt(() -> (Container) menu.getComponent(0));
        check("Switch is disabled in a 1v1", !button(menu, "Switch").isEnabled());
        shot(menu, "7-battle-1v1");
        int clicks = playUntil(menu, () -> screenName(menu).equals("ResultScreen"), 120_000, null);
        check("1v1 battle played to the result screen with real clicks (" + clicks + " clicks)",
                screenName(menu).equals("ResultScreen"));
        shot(menu, "8-result");

        // Rematch: a NEW battle screen with fresh Pokemon, without restarting the app.
        click(button(menu, "Rematch"));
        check("Rematch opens a brand-new battle screen", screenName(menu).equals("BattleScreen")
                && edt(() -> menu.getComponent(0)) != battleScreen1);
        check("rematch starts on a live battle (a turn banner is showing)", !turnText(menu).isEmpty());
        playUntil(menu, () -> screenName(menu).equals("ResultScreen"), 120_000, null);
        check("rematch played to the result screen too", screenName(menu).equals("ResultScreen"));

        click(button(menu, "New Team"));
        check("New Team goes back to selection", screenName(menu).equals("PokemonSelectionScreen"));
        click(button(menu, "Back"));
        check("Back goes to the title screen", screenName(menu).equals("TitlePanel"));
        click(button(menu, "Quit"));
        check("Quit calls the exit callback", quit[0]);
    }

    static void clickCard(Component card) throws Exception {
        edt(() -> {
            card.dispatchEvent(new MouseEvent(card, MouseEvent.MOUSE_CLICKED, System.currentTimeMillis(),
                    0, 10, 10, 1, false, MouseEvent.BUTTON1));
            return null;
        });
    }
}
