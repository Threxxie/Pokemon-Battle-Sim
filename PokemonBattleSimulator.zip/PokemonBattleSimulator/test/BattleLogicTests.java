import battle.*;
import model.*;

import java.util.*;

/**
 * Plain-Java test runner for the battle rules (no JUnit needed, no window needed).
 * Run it with:  java -cp out BattleLogicTests   (see README)
 */
public class BattleLogicTests {

    private static int passed = 0;
    private static int failed = 0;

    private static void check(String name, boolean condition) {
        if (condition) {
            passed++;
            System.out.println("  PASS  " + name);
        } else {
            failed++;
            System.out.println("  FAIL  " + name);
        }
    }

    // Helpers to build Pokemon with exact stats: name, hp, atk, def, spd, special, power
    private static Pokemon fire(String n, int hp, int atk, int def, int spd) { return new FirePokemon(n, hp, atk, def, spd, "Blast", 60); }
    private static Pokemon water(String n, int hp, int atk, int def, int spd) { return new WaterPokemon(n, hp, atk, def, spd, "Splash", 60); }
    private static Pokemon grass(String n, int hp, int atk, int def, int spd) { return new GrassPokemon(n, hp, atk, def, spd, "Leaf", 60); }
    private static Pokemon normal(String n, int hp, int atk, int def, int spd) { return new NormalPokemon(n, hp, atk, def, spd, "Slam", 60); }

    /** Player is faster (speed 100 vs 10) so the player always moves first. */
    private static BattleManager duel(Pokemon player, Pokemon opponent) {
        return new BattleManager(List.of(player), List.of(opponent), new BattleAI(new Random(1)));
    }

    public static void main(String[] args) {
        elementalMatchups();
        damageFormula();
        normalAndSpecialAttacks();
        specialCooldown();
        blocking();
        healthBounds();
        turnOrderAndInvalidActions();
        switching();
        victoryAndDefeat();
        restartAndRepeatedBattles();
        aiNeverPicksInvalidActions();

        System.out.println();
        System.out.println("Passed: " + passed + "   Failed: " + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    // ------------------------------------------------------------------

    static void elementalMatchups() {
        System.out.println("Elemental matchups");
        ElementType F = ElementType.FIRE, W = ElementType.WATER, G = ElementType.GRASS, E = ElementType.ELECTRIC,
                R = ElementType.ROCK, GH = ElementType.GHOST, N = ElementType.NORMAL;

        // Every row of the table in the assignment.
        check("Fire > Grass 2x", TypeEffectiveness.getMultiplier(F, G) == 2.0);
        check("Fire < Water 0.5x", TypeEffectiveness.getMultiplier(F, W) == 0.5);
        check("Water > Fire 2x", TypeEffectiveness.getMultiplier(W, F) == 2.0);
        check("Water < Grass 0.5x", TypeEffectiveness.getMultiplier(W, G) == 0.5);
        check("Grass > Water 2x", TypeEffectiveness.getMultiplier(G, W) == 2.0);
        check("Grass < Fire 0.5x", TypeEffectiveness.getMultiplier(G, F) == 0.5);
        check("Electric > Water 2x", TypeEffectiveness.getMultiplier(E, W) == 2.0);
        check("Electric < Rock 0.5x", TypeEffectiveness.getMultiplier(E, R) == 0.5);
        check("Rock > Fire 2x", TypeEffectiveness.getMultiplier(R, F) == 2.0);
        check("Rock < Grass 0.5x", TypeEffectiveness.getMultiplier(R, G) == 0.5);
        check("Ghost > Ghost 2x", TypeEffectiveness.getMultiplier(GH, GH) == 2.0);
        check("Ghost < Normal 0.5x", TypeEffectiveness.getMultiplier(GH, N) == 0.5);

        // Everything not in the table must be 1.0.
        int specified = 0, normalCount = 0;
        for (ElementType a : ElementType.values()) {
            for (ElementType d : ElementType.values()) {
                double m = TypeEffectiveness.getMultiplier(a, d);
                if (m != 1.0) specified++; else normalCount++;
            }
        }
        check("exactly 12 non-normal matchups out of 49", specified == 12 && normalCount == 37);
        check("Fire vs Fire is normal", TypeEffectiveness.getMultiplier(F, F) == 1.0);
        check("Normal attacker is always 1x", Arrays.stream(ElementType.values())
                .allMatch(t -> TypeEffectiveness.getMultiplier(N, t) == 1.0));

        check("message: super effective", TypeEffectiveness.describe(2.0).equals("It's super effective!"));
        check("message: not very effective", TypeEffectiveness.describe(0.5).equals("It's not very effective..."));
        check("message: normal", TypeEffectiveness.describe(1.0).equals("The attack dealt normal damage!"));

        // The message actually appears in a real attack result.
        BattleManager b = duel(fire("A", 100, 50, 50, 100), grass("B", 100, 50, 50, 10));
        ActionResult r = b.normalAttack(Side.PLAYER);
        check("attack result carries super effective text",
                r.getEffectiveness().equals("It's super effective!") && r.getMessages().contains("It's super effective!"));
    }

    static void damageFormula() {
        System.out.println("Damage formula");
        Pokemon a = normal("A", 100, 60, 50, 50);
        Pokemon d = normal("D", 100, 50, 60, 50);
        // (60 * 30 / 60) * 0.5 * 1.0 = 15
        check("normal matchup normal attack = 15", BattleManager.calculateDamage(a, d, a.getNormalAttack()) == 15);
        // (60 * 60 / 60) * 0.5 * 1.0 = 30
        check("normal matchup special = 30", BattleManager.calculateDamage(a, d, a.getSpecialAttack()) == 30);

        Pokemon f = fire("F", 100, 60, 50, 50);
        Pokemon g = grass("G", 100, 50, 60, 50);
        Pokemon w = water("W", 100, 50, 60, 50);
        check("advantage doubles damage (30)", BattleManager.calculateDamage(f, g, f.getNormalAttack()) == 30);
        check("disadvantage halves damage (8 = round 7.5)", BattleManager.calculateDamage(f, w, f.getNormalAttack()) == 8);

        Pokemon weak = normal("Weak", 100, 1, 1000, 50);
        check("minimum damage is 1", BattleManager.calculateDamage(weak, weak, weak.getNormalAttack()) == 1);
        check("applyBlock halves", BattleManager.applyBlock(30) == 15);
        check("applyBlock never below 1", BattleManager.applyBlock(1) == 1);
    }

    static void normalAndSpecialAttacks() {
        System.out.println("Normal and special attacks");
        BattleManager b = duel(normal("P", 100, 60, 50, 100), normal("O", 100, 50, 60, 10));
        Pokemon o = b.getOpponentTeam().getActive();
        ActionResult r = b.normalAttack(Side.PLAYER);
        check("normal attack is valid", r.isValid());
        check("normal attack dealt 15", r.getDamage() == 15 && o.getCurrentHp() == 85);
        check("normal attack says 'normal damage'", r.getEffectiveness().equals("The attack dealt normal damage!"));
        check("turn passed to opponent", b.getCurrentSide() == Side.OPPONENT);

        b.normalAttack(Side.OPPONENT);
        r = b.specialAttack(Side.PLAYER);
        check("special attack dealt 30", r.isValid() && r.getDamage() == 30 && o.getCurrentHp() == 55);
        check("special attack name is in the log", r.getMessages().get(0).contains("Slam"));
        check("special deals more than normal", r.getDamage() > 15);

        // Polymorphism: the flavor text differs by subclass.
        Pokemon p1 = fire("X", 10, 1, 1, 1), p2 = water("Y", 10, 1, 1, 1);
        check("subclasses describe specials differently", !p1.describeSpecialAttack().equals(p2.describeSpecialAttack().replace("Y", "X")));
    }

    static void specialCooldown() {
        System.out.println("Special attack cooldown");
        BattleManager b = duel(normal("P", 1000, 60, 50, 100), normal("O", 1000, 50, 60, 10));
        check("special ready at start", b.getPlayerTeam().getActive().getSpecialAttack().isAvailable());
        check("first special works", b.specialAttack(Side.PLAYER).isValid());
        b.normalAttack(Side.OPPONENT);

        // Player turn 2 and 3: cooldown still running.
        ActionResult r = b.specialAttack(Side.PLAYER);
        check("special rejected on cooldown (turn 2)", !r.isValid());
        check("rejected special did not use the turn", b.getCurrentSide() == Side.PLAYER);
        check("cooldown shows 2 turns", b.getPlayerTeam().getActive().getSpecialAttack().getCooldownRemaining() == 2);
        b.normalAttack(Side.PLAYER);
        b.normalAttack(Side.OPPONENT);
        check("special rejected on cooldown (turn 3)", !b.specialAttack(Side.PLAYER).isValid());
        b.normalAttack(Side.PLAYER);
        b.normalAttack(Side.OPPONENT);
        check("special ready again on turn 4", b.specialAttack(Side.PLAYER).isValid());
    }

    static void blocking() {
        System.out.println("Blocking");
        BattleManager b = duel(normal("P", 100, 60, 50, 100), normal("O", 100, 60, 50, 10));
        Pokemon p = b.getPlayerTeam().getActive();
        // Damage for a normal attack here is (60*30/50)*0.5 = 18
        check("player blocks", b.block(Side.PLAYER).isValid());
        check("blocking flag set", p.isBlocking());
        ActionResult hit = b.normalAttack(Side.OPPONENT);
        check("blocked hit deals half (9)", hit.getDamage() == 9 && p.getCurrentHp() == 91);
        check("block message shown", hit.getMessages().stream().anyMatch(m -> m.contains("blocked")));
        check("block expires after the attack", !p.isBlocking());

        // Player's next turn: cannot block twice in a row.
        ActionResult again = b.block(Side.PLAYER);
        check("cannot block two turns in a row", !again.isValid() && b.getCurrentSide() == Side.PLAYER);
        b.normalAttack(Side.PLAYER);
        ActionResult full = b.normalAttack(Side.OPPONENT);
        check("later hits are full damage again (18)", full.getDamage() == 18);
        check("can block again after attacking", b.block(Side.PLAYER).isValid());

        // A block that is never hit expires at the start of the blocker's next turn.
        BattleManager c = duel(normal("P", 100, 60, 50, 100), normal("O", 100, 60, 50, 10));
        c.block(Side.PLAYER);
        c.block(Side.OPPONENT);   // the opponent doesn't attack
        check("unused block expired when the turn came back", !c.getPlayerTeam().getActive().isBlocking());
        check("block never changes the defense stat", c.getPlayerTeam().getActive().getDefenseStat() == 50);
    }

    static void healthBounds() {
        System.out.println("Health limits");
        Pokemon p = normal("P", 50, 10, 10, 10);
        check("negative damage ignored", p.takeDamage(-20) == 0 && p.getCurrentHp() == 50);
        check("overkill is clamped", p.takeDamage(9999) == 50 && p.getCurrentHp() == 0);
        check("health never negative", p.getCurrentHp() >= 0 && p.isFainted());
        p.heal(30);
        check("fainted Pokemon cannot be healed", p.getCurrentHp() == 0);
        Pokemon q = normal("Q", 50, 10, 10, 10);
        q.takeDamage(10);
        q.heal(1000);
        check("heal caps at max HP", q.getCurrentHp() == 50);

        // A fainted Pokemon cannot attack.
        BattleManager b = duel(normal("P", 100, 60, 50, 100), normal("O", 100, 60, 50, 10));
        b.getPlayerTeam().getActive().takeDamage(1000);
        check("fainted attacker is rejected", !b.normalAttack(Side.PLAYER).isValid());
        check("fainted blocker is rejected", !b.block(Side.PLAYER).isValid());
    }

    static void turnOrderAndInvalidActions() {
        System.out.println("Turn order and invalid actions");
        BattleManager faster = duel(normal("P", 100, 50, 50, 100), normal("O", 100, 50, 50, 10));
        check("faster player goes first", faster.getCurrentSide() == Side.PLAYER);
        BattleManager slower = duel(normal("P", 100, 50, 50, 10), normal("O", 100, 50, 50, 100));
        check("faster opponent goes first", slower.getCurrentSide() == Side.OPPONENT);
        BattleManager tie = duel(normal("P", 100, 50, 50, 50), normal("O", 100, 50, 50, 50));
        check("speed tie goes to the player", tie.getCurrentSide() == Side.PLAYER);

        ActionResult r = slower.normalAttack(Side.PLAYER);
        check("acting out of turn is rejected", !r.isValid() && slower.getOpponentTeam().getActive().getCurrentHp() == 100
                && slower.getPlayerTeam().getActive().getCurrentHp() == 100);
        check("rejected action leaves turn unchanged", slower.getCurrentSide() == Side.OPPONENT);
        check("every rejection explains itself", !r.getMessages().get(0).isBlank());
    }

    static void switching() {
        System.out.println("Switching");
        BattleManager b = new BattleManager(
                List.of(normal("A", 100, 60, 50, 100), normal("B", 100, 60, 50, 50), normal("C", 100, 60, 50, 50)),
                List.of(normal("X", 100, 60, 50, 10), normal("Y", 100, 60, 50, 10)),
                new BattleAI(new Random(1)));
        Team mine = b.getPlayerTeam();
        check("cannot switch to the active Pokemon", !b.switchPokemon(Side.PLAYER, 0).isValid());
        check("cannot switch to an invalid index", !b.switchPokemon(Side.PLAYER, 7).isValid() && !b.switchPokemon(Side.PLAYER, -1).isValid());
        mine.getMembers().get(2).takeDamage(1000);
        check("cannot switch to a fainted Pokemon", !b.switchPokemon(Side.PLAYER, 2).isValid());
        check("failed switches did not use the turn", b.getCurrentSide() == Side.PLAYER);

        ActionResult r = b.switchPokemon(Side.PLAYER, 1);
        check("valid switch works", r.isValid() && mine.getActive().getName().equals("B"));
        check("switching uses the turn", b.getCurrentSide() == Side.OPPONENT);
        check("team list is read-only", throwsOnModify(mine));

        // Forced replacement when the active Pokemon faints.
        mine.getActive().takeDamage(mine.getActive().getCurrentHp() - 1); // B has 1 HP left
        ActionResult ko = b.normalAttack(Side.OPPONENT);
        check("player Pokemon fainted", mine.getMembers().get(1).isFainted());
        check("battle waits for a replacement", b.isAwaitingPlayerReplacement() && !b.isBattleOver());
        check("no actions while choosing", !b.normalAttack(Side.PLAYER).isValid());
        check("cannot pick the fainted one", !b.chooseReplacement(1).isValid() && !b.chooseReplacement(2).isValid());
        check("replacement works", b.chooseReplacement(0).isValid() && mine.getActive().getName().equals("A"));
        check("replacement is free: player's turn", b.getCurrentSide() == Side.PLAYER && !b.isAwaitingPlayerReplacement());
        check("replacement outside a faint is rejected", !b.chooseReplacement(1).isValid());

        // Opponent replacement is automatic.
        b.getOpponentTeam().getActive().takeDamage(99);
        b.normalAttack(Side.PLAYER);
        check("opponent auto-sends next Pokemon", b.getOpponentTeam().getActive().getName().equals("Y") && !b.isBattleOver());
    }

    private static boolean throwsOnModify(Team t) {
        try {
            t.getMembers().clear();
            return false;
        } catch (UnsupportedOperationException e) {
            return true;
        }
    }

    static void victoryAndDefeat() {
        System.out.println("Victory and defeat");
        BattleManager win = duel(normal("P", 100, 60, 50, 100), normal("O", 10, 50, 60, 10));
        ActionResult r = win.specialAttack(Side.PLAYER);
        check("opponent faints", win.getOpponentTeam().getActive().isFainted() && win.getOpponentTeam().getActive().getCurrentHp() == 0);
        check("player is the winner", win.isBattleOver() && win.getWinner() == Side.PLAYER);
        check("win message logged", r.getMessages().stream().anyMatch(m -> m.contains("You win")));
        check("no actions after winning (attack)", !win.normalAttack(Side.PLAYER).isValid());
        check("no actions after winning (special)", !win.specialAttack(Side.PLAYER).isValid());
        check("no actions after winning (block)", !win.block(Side.PLAYER).isValid());
        check("no actions after winning (opponent)", !win.performOpponentTurn().isValid());

        BattleManager lose = duel(normal("P", 10, 50, 60, 10), normal("O", 100, 60, 50, 100));
        // opponent is faster
        lose.specialAttack(Side.OPPONENT);
        check("player loses when the last Pokemon faints", lose.isBattleOver() && lose.getWinner() == Side.OPPONENT);
        check("no actions after losing", !lose.normalAttack(Side.PLAYER).isValid() && !lose.switchPokemon(Side.PLAYER, 0).isValid());

        // Team battle: the battle only ends when a whole team is out.
        BattleManager team = new BattleManager(
                List.of(normal("A", 100, 60, 50, 100), normal("B", 100, 60, 50, 50)),
                List.of(normal("X", 10, 60, 50, 10), normal("Y", 10, 60, 50, 10)),
                new BattleAI(new Random(1)));
        team.normalAttack(Side.PLAYER);
        check("not over after first KO", !team.isBattleOver());
        team.normalAttack(Side.OPPONENT);
        team.normalAttack(Side.PLAYER);
        check("over after second KO, player wins", team.isBattleOver() && team.getWinner() == Side.PLAYER);
    }

    static void restartAndRepeatedBattles() {
        System.out.println("Restart and repeated battles");
        List<String> picks = List.of("Charizard", "Pikachu");
        for (int round = 1; round <= 5; round++) {
            Random rng = new Random(round);
            BattleManager b = new BattleManager(PokemonFactory.createTeam(picks),
                    PokemonFactory.createOpponentTeam(picks, rng), new BattleAI(rng));
            boolean fresh = b.getPlayerTeam().getMembers().stream().allMatch(p ->
                    p.getCurrentHp() == p.getMaxHp() && p.getSpecialAttack().isAvailable() && !p.isBlocking())
                    && b.getOpponentTeam().getMembers().stream().allMatch(p -> p.getCurrentHp() == p.getMaxHp());
            boolean ended = playOut(b, new BattleAI(rng), 500);
            check("round " + round + ": fresh start, battle ends with a winner", fresh && ended && b.getWinner() != null);
        }
        List<Pokemon> opp = PokemonFactory.createOpponentTeam(picks, new Random(3));
        check("opponents never include the player's picks",
                opp.stream().noneMatch(p -> picks.contains(p.getName())) && opp.size() == picks.size());
    }

    /** Runs a whole battle with an AI on each side. Returns false if any action was rejected or it never ended. */
    private static boolean playOut(BattleManager b, BattleAI playerAi, int maxSteps) {
        for (int step = 0; step < maxSteps && !b.isBattleOver(); step++) {
            ActionResult r;
            if (b.isAwaitingPlayerReplacement()) {
                r = b.chooseReplacement(playerAi.chooseReplacement(b.getPlayerTeam(), b.getOpponentTeam().getActive()));
            } else if (b.getCurrentSide() == Side.OPPONENT) {
                r = b.performOpponentTurn();
            } else {
                Pokemon me = b.getPlayerTeam().getActive();
                switch (playerAi.chooseAction(me, b.getOpponentTeam().getActive())) {
                    case SPECIAL_ATTACK: r = b.specialAttack(Side.PLAYER); break;
                    case BLOCK: r = b.block(Side.PLAYER); break;
                    default: r = b.normalAttack(Side.PLAYER);
                }
            }
            if (!r.isValid()) {
                System.out.println("    rejected: " + r.getMessages().get(0));
                return false;
            }
        }
        return b.isBattleOver();
    }

    static void aiNeverPicksInvalidActions() {
        System.out.println("AI never picks an invalid action (all 1v1 pairings x 20 seeds, plus 3v3)");
        List<String> names = PokemonFactory.getRosterNames();
        boolean allFine = true;
        int battles = 0;
        int playerWins = 0;
        int maxTurns = 0;
        for (String a : names) {
            for (String o : names) {
                if (a.equals(o)) continue;
                for (int seed = 0; seed < 20; seed++) {
                    Random rng = new Random(seed);
                    BattleManager b = new BattleManager(List.of(PokemonFactory.create(a)),
                            List.of(PokemonFactory.create(o)), new BattleAI(rng));
                    if (!playOut(b, new BattleAI(rng), 500)) {
                        allFine = false;
                        System.out.println("    problem in " + a + " vs " + o + " seed " + seed);
                    }
                    battles++;
                    if (b.getWinner() == Side.PLAYER) playerWins++;
                    maxTurns = Math.max(maxTurns, b.getTurnNumber());
                }
            }
        }
        check(battles + " 1v1 AI-vs-AI battles all finished with only valid actions", allFine);
        System.out.println("        (longest battle: " + maxTurns + " turns; first-listed side won "
                + playerWins + "/" + battles + ")");

        boolean teamsFine = true;
        for (int seed = 0; seed < 200; seed++) {
            Random rng = new Random(seed);
            List<String> picks = new ArrayList<>(names);
            Collections.shuffle(picks, rng);
            picks = picks.subList(0, 3);
            BattleManager b = new BattleManager(PokemonFactory.createTeam(picks),
                    PokemonFactory.createOpponentTeam(picks, rng), new BattleAI(rng));
            teamsFine &= playOut(b, new BattleAI(rng), 1000);
        }
        check("200 random 3v3 AI-vs-AI battles all finished with only valid actions", teamsFine);

        // Direct check of the decision rules.
        BattleAI ai = new BattleAI(new Random(5));
        boolean legal = true;
        for (int i = 0; i < 5000; i++) {
            Pokemon self = PokemonFactory.create(names.get(i % names.size()));
            Pokemon enemy = PokemonFactory.create(names.get((i * 3 + 1) % names.size()));
            self.takeDamage(i % self.getMaxHp());
            if (i % 2 == 0) self.getSpecialAttack().onUse();
            if (i % 3 == 0) { self.block(); self.startTurn(); }
            BattleAI.Choice c = ai.chooseAction(self, enemy);
            if (c == BattleAI.Choice.SPECIAL_ATTACK && !self.getSpecialAttack().isAvailable()) legal = false;
            if (c == BattleAI.Choice.BLOCK && !self.canBlock()) legal = false;
        }
        check("5000 sampled AI decisions were all legal", legal);
    }
}
