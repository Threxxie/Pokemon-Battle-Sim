Optional: drop PNG images here named after the Pokemon in lowercase
(pikachu.png, charizard.png, ...). If a file exists it replaces the built-in
placeholder drawing. Square images look best. Run the game from the project
root folder so this "sprites" folder is found.
