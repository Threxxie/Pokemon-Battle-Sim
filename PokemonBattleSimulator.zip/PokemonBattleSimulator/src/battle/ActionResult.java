package battle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * What happened when someone tried to act. The UI reads this object to update
 * the battle log, so the UI never needs to know any battle rules.
 *
 * If valid is false, the action was rejected (wrong turn, move on cooldown, ...),
 * nothing changed, and the turn was NOT used up.
 */
public class ActionResult {

    private final boolean valid;
    private final Side actor;
    private final List<String> messages;
    private final String effectiveness;   // null when the action was not an attack
    private final double multiplier;      // 1.0 when the action was not an attack
    private final int damage;

    public ActionResult(boolean valid, Side actor, List<String> messages,
                        String effectiveness, double multiplier, int damage) {
        this.valid = valid;
        this.actor = actor;
        this.messages = Collections.unmodifiableList(new ArrayList<>(messages));
        this.effectiveness = effectiveness;
        this.multiplier = multiplier;
        this.damage = damage;
    }

    public static ActionResult invalid(Side actor, String reason) {
        return new ActionResult(false, actor, List.of(reason), null, 1.0, 0);
    }

    public boolean isValid() { return valid; }
    public Side getActor() { return actor; }
    public List<String> getMessages() { return messages; }
    public String getEffectiveness() { return effectiveness; }
    public double getMultiplier() { return multiplier; }
    public int getDamage() { return damage; }
}
