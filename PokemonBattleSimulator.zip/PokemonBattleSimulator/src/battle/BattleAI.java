package battle;

import model.Pokemon;
import model.Team;

import java.util.Random;

/**
 * Simple rule-based opponent. It only ever returns actions that are currently legal.
 *
 * Rules, in order:
 *  1. Low health: sometimes block (if allowed).
 *  2. Enemy has a type advantage over us: occasionally block (if allowed).
 *  3. Special attack ready: use it when we have an advantage, usually when the matchup
 *     is even, and rarely when we are at a disadvantage.
 *  4. Otherwise use a normal attack.
 */
public class BattleAI {

    public enum Choice { NORMAL_ATTACK, SPECIAL_ATTACK, BLOCK }

    private static final double LOW_HEALTH_FRACTION = 0.30;

    private final Random random;

    public BattleAI(Random random) {
        this.random = random;
    }

    public Choice chooseAction(Pokemon self, Pokemon enemy) {
        double myMultiplier = TypeEffectiveness.getMultiplier(self.getType(), enemy.getType());
        double enemyMultiplier = TypeEffectiveness.getMultiplier(enemy.getType(), self.getType());
        boolean lowHealth = self.getCurrentHp() <= self.getMaxHp() * LOW_HEALTH_FRACTION;

        // 1. Defensive play when hurt.
        if (self.canBlock() && lowHealth && random.nextDouble() < 0.5) {
            return Choice.BLOCK;
        }
        // 2. Expecting a strong hit.
        if (self.canBlock() && enemyMultiplier > TypeEffectiveness.NORMAL && random.nextDouble() < 0.25) {
            return Choice.BLOCK;
        }
        // 3. Special attack, if it is off cooldown.
        if (self.getSpecialAttack().isAvailable()) {
            if (myMultiplier > TypeEffectiveness.NORMAL) {
                return Choice.SPECIAL_ATTACK;
            }
            double chance = myMultiplier == TypeEffectiveness.NORMAL ? 0.6 : 0.2;
            if (random.nextDouble() < chance) {
                return Choice.SPECIAL_ATTACK;
            }
        }
        // 4. Default.
        return Choice.NORMAL_ATTACK;
    }

    /**
     * Picks which teammate to send out after a faint: the best type matchup against the
     * enemy, using remaining health as a small tie-breaker.
     * @return the team index to switch to, or -1 if nobody is available
     */
    public int chooseReplacement(Team team, Pokemon enemyActive) {
        int best = -1;
        double bestScore = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < team.size(); i++) {
            if (!team.canSwitchTo(i)) {
                continue;
            }
            Pokemon candidate = team.getMembers().get(i);
            double score = TypeEffectiveness.getMultiplier(candidate.getType(), enemyActive.getType())
                    - TypeEffectiveness.getMultiplier(enemyActive.getType(), candidate.getType())
                    + 0.1 * candidate.getCurrentHp() / candidate.getMaxHp();
            if (score > bestScore) {
                bestScore = score;
                best = i;
            }
        }
        return best;
    }
}
