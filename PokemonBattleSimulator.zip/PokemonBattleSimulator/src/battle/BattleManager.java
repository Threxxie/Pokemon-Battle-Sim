package battle;

import model.Move;
import model.Pokemon;
import model.Team;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Owns all the battle RULES: whose turn it is, applying attacks, damage, blocking,
 * fainting, switching and deciding the winner. It contains no Swing code, so it
 * can be tested without a window and the UI just calls its methods.
 *
 * Turn system:
 *  - The Pokemon with the higher Speed stat moves first (the player wins ties).
 *  - After that the two sides strictly alternate.
 *  - An action that is rejected (invalid) does not use up the turn.
 *  - When the player's Pokemon faints, the battle waits for the player to choose a
 *    replacement; that replacement is free and the player then takes their turn.
 *    The opponent's replacement is chosen automatically by the AI.
 */
public class BattleManager {

    /**
     * Damage formula:
     *   damage = (attackerAttack * movePower / defenderDefense) * DAMAGE_SCALE * typeMultiplier
     * The result is rounded to a whole number and is never lower than 1.
     * DAMAGE_SCALE just keeps battles at a good length (about 5-10 turns).
     */
    public static final double DAMAGE_SCALE = 0.5;

    /** A block cuts the incoming damage in half (still at least 1). */
    public static final double BLOCK_MULTIPLIER = 0.5;

    private final Team playerTeam;
    private final Team opponentTeam;
    private final BattleAI ai;

    private Side currentSide;
    private Side winner = null;
    private boolean awaitingPlayerReplacement = false;
    private int turnNumber = 1;

    public BattleManager(List<Pokemon> playerPokemon, List<Pokemon> opponentPokemon) {
        this(playerPokemon, opponentPokemon, new BattleAI(new Random()));
    }

    public BattleManager(List<Pokemon> playerPokemon, List<Pokemon> opponentPokemon, BattleAI ai) {
        this.playerTeam = new Team(playerPokemon);
        this.opponentTeam = new Team(opponentPokemon);
        this.ai = ai;

        boolean playerFirst = playerTeam.getActive().getSpeedStat() >= opponentTeam.getActive().getSpeedStat();
        this.currentSide = playerFirst ? Side.PLAYER : Side.OPPONENT;
        (playerFirst ? playerTeam : opponentTeam).getActive().startTurn();
    }

    // ------------------------------------------------------------------
    // State the UI can read
    // ------------------------------------------------------------------

    public Team getPlayerTeam() { return playerTeam; }
    public Team getOpponentTeam() { return opponentTeam; }
    public Team teamOf(Side side) { return side == Side.PLAYER ? playerTeam : opponentTeam; }
    public Side getCurrentSide() { return currentSide; }
    public Side getWinner() { return winner; }
    public boolean isBattleOver() { return winner != null; }
    public boolean isAwaitingPlayerReplacement() { return awaitingPlayerReplacement; }
    public int getTurnNumber() { return turnNumber; }

    // ------------------------------------------------------------------
    // Damage calculation (public and static so it is easy to test)
    // ------------------------------------------------------------------

    public static int calculateDamage(Pokemon attacker, Pokemon defender, Move move) {
        double multiplier = TypeEffectiveness.getMultiplier(attacker.getType(), defender.getType());
        double raw = (double) attacker.getAttackStat() * move.getPower() / defender.getDefenseStat()
                * DAMAGE_SCALE * multiplier;
        return Math.max(1, (int) Math.round(raw));
    }

    public static int applyBlock(int damage) {
        return Math.max(1, (int) Math.round(damage * BLOCK_MULTIPLIER));
    }

    // ------------------------------------------------------------------
    // Actions. Each returns an ActionResult describing what happened.
    // ------------------------------------------------------------------

    public ActionResult normalAttack(Side side) {
        return attack(side, false);
    }

    public ActionResult specialAttack(Side side) {
        return attack(side, true);
    }

    public ActionResult block(Side side) {
        ActionResult problem = checkCanAct(side);
        if (problem != null) {
            return problem;
        }
        Pokemon pokemon = teamOf(side).getActive();
        if (!pokemon.canBlock()) {
            return ActionResult.invalid(side, pokemon.getName() + " can't block two turns in a row!");
        }
        pokemon.block();
        List<String> log = new ArrayList<>();
        log.add(pokemon.getName() + " raises its guard!");
        advanceTurn(side);
        return new ActionResult(true, side, log, null, 1.0, 0);
    }

    /** Voluntary switch. It uses up the turn. */
    public ActionResult switchPokemon(Side side, int teamIndex) {
        ActionResult problem = checkCanAct(side);
        if (problem != null) {
            return problem;
        }
        Team team = teamOf(side);
        if (!team.canSwitchTo(teamIndex)) {
            return ActionResult.invalid(side, "That Pokemon can't be sent out!");
        }
        List<String> log = new ArrayList<>();
        String outgoing = team.getActive().getName();
        team.switchTo(teamIndex);
        log.add(outgoing + ", come back!");
        log.add("Go, " + team.getActive().getName() + "!");
        advanceTurn(side);
        return new ActionResult(true, side, log, null, 1.0, 0);
    }

    /** Free switch the player must make after their Pokemon faints. Does not use up a turn. */
    public ActionResult chooseReplacement(int teamIndex) {
        if (!awaitingPlayerReplacement) {
            return ActionResult.invalid(Side.PLAYER, "No replacement is needed right now.");
        }
        if (!playerTeam.canSwitchTo(teamIndex)) {
            return ActionResult.invalid(Side.PLAYER, "That Pokemon can't be sent out!");
        }
        playerTeam.switchTo(teamIndex);
        awaitingPlayerReplacement = false;
        playerTeam.getActive().startTurn(); // it is the player's turn now
        List<String> log = new ArrayList<>();
        log.add("Go, " + playerTeam.getActive().getName() + "!");
        return new ActionResult(true, Side.PLAYER, log, null, 1.0, 0);
    }

    /** Lets the AI take the opponent's turn. */
    public ActionResult performOpponentTurn() {
        ActionResult problem = checkCanAct(Side.OPPONENT);
        if (problem != null) {
            return problem;
        }
        Pokemon self = opponentTeam.getActive();
        Pokemon enemy = playerTeam.getActive();
        switch (ai.chooseAction(self, enemy)) {
            case SPECIAL_ATTACK:
                return specialAttack(Side.OPPONENT);
            case BLOCK:
                return block(Side.OPPONENT);
            default:
                return normalAttack(Side.OPPONENT);
        }
    }

    // ------------------------------------------------------------------
    // Internals
    // ------------------------------------------------------------------

    /** Returns null if the side may act, otherwise an invalid result explaining why not. */
    private ActionResult checkCanAct(Side side) {
        if (isBattleOver()) {
            return ActionResult.invalid(side, "The battle is already over.");
        }
        if (awaitingPlayerReplacement) {
            return ActionResult.invalid(side, "Choose a Pokemon to send out first.");
        }
        if (side != currentSide) {
            return ActionResult.invalid(side, "It's not your turn yet.");
        }
        if (teamOf(side).getActive().isFainted()) {
            return ActionResult.invalid(side, "A fainted Pokemon can't act.");
        }
        return null;
    }

    private ActionResult attack(Side side, boolean special) {
        ActionResult problem = checkCanAct(side);
        if (problem != null) {
            return problem;
        }
        Pokemon attacker = teamOf(side).getActive();
        Pokemon defender = teamOf(side.other()).getActive();
        Move move = special ? attacker.getSpecialAttack() : attacker.getNormalAttack();

        if (!move.isAvailable()) {
            return ActionResult.invalid(side, move.getName() + " is still on cooldown!");
        }

        List<String> log = new ArrayList<>();
        log.add(special
                ? attacker.describeSpecialAttack()
                : attacker.getName() + " uses " + move.getName() + "!");
        move.onUse();

        double multiplier = TypeEffectiveness.getMultiplier(attacker.getType(), defender.getType());
        String effectiveness = TypeEffectiveness.describe(multiplier);
        log.add(effectiveness);

        int damage = calculateDamage(attacker, defender, move);
        if (defender.isBlocking()) {
            damage = applyBlock(damage);
            defender.endBlock(); // a block only lasts for one attack
            log.add(defender.getName() + " blocked and took reduced damage!");
        }

        int dealt = defender.takeDamage(damage);
        log.add(defender.getName() + " took " + dealt + " damage. (HP "
                + defender.getCurrentHp() + "/" + defender.getMaxHp() + ")");

        if (defender.isFainted()) {
            log.add(defender.getName() + " fainted!");
            handleFaint(side.other(), log);
        }
        if (!isBattleOver()) {
            advanceTurn(side);
        }
        return new ActionResult(true, side, log, effectiveness, multiplier, dealt);
    }

    private void handleFaint(Side faintedSide, List<String> log) {
        Team team = teamOf(faintedSide);
        if (!team.hasRemaining()) {
            winner = faintedSide.other();
            log.add(winner == Side.PLAYER
                    ? "The opposing team is out of Pokemon. You win!"
                    : "All of your Pokemon have fainted. You lose!");
            return;
        }
        if (faintedSide == Side.OPPONENT) {
            int next = ai.chooseReplacement(team, playerTeam.getActive());
            team.switchTo(next);
            log.add("The opponent sends out " + team.getActive().getName() + "!");
        } else {
            awaitingPlayerReplacement = true;
            log.add("Choose your next Pokemon!");
        }
    }

    /** Hands the turn to the other side and starts that Pokemon's turn. */
    private void advanceTurn(Side finished) {
        currentSide = finished.other();
        turnNumber++;
        Pokemon next = teamOf(currentSide).getActive();
        if (!next.isFainted()) { // a fainted player Pokemon starts its turn after being replaced
            next.startTurn();
        }
    }
}
