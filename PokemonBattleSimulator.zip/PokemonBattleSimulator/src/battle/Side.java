package battle;

/** The two participants in a battle. */
public enum Side {
    PLAYER,
    OPPONENT;

    public Side other() {
        return this == PLAYER ? OPPONENT : PLAYER;
    }
}
