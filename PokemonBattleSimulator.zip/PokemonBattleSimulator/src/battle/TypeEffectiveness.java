package battle;

import model.ElementType;

import java.util.EnumMap;
import java.util.Map;

/**
 * The single place where elemental matchups are decided.
 * Every other class asks this one, so no matchup checks are scattered around.
 *
 * Each attacking type has at most one type it is strong against (2x) and one type
 * it is weak against (0.5x). Everything else is a normal 1x matchup.
 * These rules are simplified and differ from the official games on purpose.
 */
public final class TypeEffectiveness {

    public static final double ADVANTAGE = 2.0;
    public static final double DISADVANTAGE = 0.5;
    public static final double NORMAL = 1.0;

    private static final Map<ElementType, ElementType> STRONG_AGAINST = new EnumMap<>(ElementType.class);
    private static final Map<ElementType, ElementType> WEAK_AGAINST = new EnumMap<>(ElementType.class);

    static {
        // attacker               strong against         weak against
        add(ElementType.FIRE,     ElementType.GRASS,     ElementType.WATER);
        add(ElementType.WATER,    ElementType.FIRE,      ElementType.GRASS);
        add(ElementType.GRASS,    ElementType.WATER,     ElementType.FIRE);
        add(ElementType.ELECTRIC, ElementType.WATER,     ElementType.ROCK);
        add(ElementType.ROCK,     ElementType.FIRE,      ElementType.GRASS);
        add(ElementType.GHOST,    ElementType.GHOST,     ElementType.NORMAL);
    }

    private TypeEffectiveness() { }

    private static void add(ElementType attacker, ElementType strong, ElementType weak) {
        STRONG_AGAINST.put(attacker, strong);
        WEAK_AGAINST.put(attacker, weak);
    }

    /** Returns 2.0, 0.5 or 1.0 for an attack of type {@code attacker} hitting type {@code defender}. */
    public static double getMultiplier(ElementType attacker, ElementType defender) {
        if (STRONG_AGAINST.get(attacker) == defender) {
            return ADVANTAGE;
        }
        if (WEAK_AGAINST.get(attacker) == defender) {
            return DISADVANTAGE;
        }
        return NORMAL;
    }

    /** The message shown to the player after an attack. */
    public static String describe(double multiplier) {
        if (multiplier > NORMAL) {
            return "It's super effective!";
        }
        if (multiplier < NORMAL) {
            return "It's not very effective...";
        }
        return "The attack dealt normal damage!";
    }
}
