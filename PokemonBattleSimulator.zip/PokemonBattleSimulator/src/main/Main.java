package main;

import ui.MainMenu;
import ui.Theme;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/** Program entry point: opens the game window on the Swing event thread. */
public class Main {

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame(Theme.POKEMON + " Battle Simulator");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setContentPane(new MainMenu(frame::dispose));
            frame.setMinimumSize(new Dimension(1000, 740));
            frame.setSize(1120, 800);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
