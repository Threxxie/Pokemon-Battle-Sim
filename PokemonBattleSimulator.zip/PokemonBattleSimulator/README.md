# Pokémon Battle Simulator (Java / Swing)

A turn-based, Pokémon-inspired battle game built to practice **object-oriented programming in Java**.
Pick 1–3 Pokémon, then fight an AI opponent using normal attacks, cooldown-limited special attacks,
blocking and switching. Everything runs offline with only the standard Java library.

| Title | Selection | Battle |
|---|---|---|
| ![title](docs/title.png) | ![selection](docs/selection.png) | ![battle](docs/battle.png) |

![blocking](docs/blocking.png)

## Features
- 8 Pokémon across 7 elemental types, each with its own special attack
- Elemental advantage (2x), disadvantage (0.5x) and normal (1x) damage, with on-screen messages
- Normal attack, special attack (3-turn cooldown), block (halves the next hit), switch
- 1v1 or team battles (up to 3v3) with forced replacement when a Pokémon faints
- Rule-based AI opponent; Speed decides who moves first
- Animated health bars, turn indicator, battle log, shield indicator, victory/defeat screen, rematch
- Placeholder sprites are drawn in code; optional PNGs can be dropped into `sprites/`

## Requirements
Java 17 or newer (JDK, so that `javac` is available). Developed and tested with OpenJDK 21.

## Compile and run
From the project root:

**macOS / Linux**
```bash
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp out main.Main
```

**Windows (Command Prompt)**
```bat
mkdir out
dir /s /b src\*.java > sources.txt
javac -d out @sources.txt
java -cp out main.Main
```
Run from the project root so the optional `sprites/` folder is found.

## Run the tests
```bash
javac -d out $(find src test -name "*.java")
java -cp out BattleLogicTests                                   # battle rules, no window needed
java -Djava.awt.headless=true -cp out GuiHeadlessTest shots     # UI screens, saves screenshots to shots/
```

## How to play
1. **Start Battle**, then click 1–3 Pokémon (the first pick leads). The opponent brings the same number from the Pokémon you did not pick.
2. On your turn choose **Normal Attack**, the **Special** (shown by its move name; on cooldown after use), **Block**, or **Switch**.
3. Block halves the next attack against you and cannot be used two turns in a row.
4. The battle ends when one side runs out of Pokémon. Choose **Rematch**, **New Team** or **Main Menu**.

## Project structure
```
src/
  main/Main.java                 launches the window
  model/                         the data: Pokémon, moves, teams
    Pokemon.java                 abstract base class (encapsulated state)
    FirePokemon, WaterPokemon, GrassPokemon, ElectricPokemon,
    RockPokemon, GhostPokemon, NormalPokemon     one small subclass per type
    Move.java, NormalAttack.java, SpecialAttack.java
    Team.java, ElementType.java, PokemonFactory.java
  battle/                        the rules (no Swing code)
    BattleManager.java           turns, damage, blocking, fainting, winner
    TypeEffectiveness.java       the only place matchups are decided
    BattleAI.java                opponent decisions
    ActionResult.java, Side.java
  ui/                            Swing screens and widgets
    MainMenu, PokemonSelectionScreen, BattleScreen, ResultScreen,
    FighterPanel, SwitchDialog, SpritePanel, HealthBar, Badge,
    RoundedPanel, RoundedButton, Theme
test/
  BattleLogicTests.java, GuiHeadlessTest.java
```

## OOP concepts demonstrated
- **Encapsulation** – `Pokemon` fields are private. HP changes only through `takeDamage()`/`heal()`, which clamp it to `0..maxHp`. `Team.getMembers()` returns a read-only list.
- **Inheritance** – `FirePokemon`, `WaterPokemon`, … extend `Pokemon` and reuse all of its behaviour. One subclass per *type* (not per Pokémon) keeps this from becoming repetitive: Charizard and Charmander are both just `FirePokemon` objects with different stats.
- **Polymorphism** – `describeSpecialAttack()` is abstract and each subclass writes its own version, yet callers only use a `Pokemon` reference. `BattleManager` also treats `NormalAttack` and `SpecialAttack` identically through the `Move` interface.
- **Abstraction** – `Move` hides *how* availability works (a normal attack is always available; a special has a cooldown). `Pokemon` is abstract so only concrete types can be created.
- **Separation of concerns** – `battle` contains no Swing code, so the rules are testable without a window. The UI only calls `BattleManager` and displays the returned `ActionResult`.

## Battle rules
```
damage = (attackerAttack * movePower / defenderDefense) * 0.5 * typeMultiplier   (rounded, minimum 1)
blocked damage = damage * 0.5                                                      (rounded, minimum 1)
```
Normal attack power is 30; special attacks are 60–70. Type multipliers: 2.0 / 0.5 / 1.0 using the table in `TypeEffectiveness`
(simplified and different from the official games on purpose).

## What has been verified
- `BattleLogicTests`: 99 checks pass, including every row of the type table, exact damage values, cooldown, blocking, health limits, turn order, invalid actions, switching, forced replacement, victory/defeat, and 1,120 AI-vs-AI 1v1 battles plus 200 random 3v3 battles that all ended with only legal actions.
- `GuiHeadlessTest`: the real panels were driven with simulated clicks (title → selection → battle → result → rematch → new team → menu, a full 3v3 battle, the block indicator) and painted to images that were inspected by eye.

## Known limitations
- **Not tested in a real window.** The test machine had no display, so the `JFrame` created in `Main` and the pop-up `SwitchDialog` (voluntary and forced switching) were never opened on screen; the UI was verified headlessly instead (see above). The switching *rules* are tested; the dialog's appearance is not. If something looks off on your machine, `SwitchDialog.java` and `Main.java` are the first places to check.
- Animations (health bar slide, hit shake) were not observed in motion.
- Damage is deterministic (no randomness, critical hits or accuracy).
- Turns alternate strictly after the first move; Speed only decides who starts.
- The AI never switches voluntarily and does not predict your next move.
- Placeholder sprites are simple drawings, not official artwork.
- Pokémon is a trademark of Nintendo / Game Freak. This is an unofficial educational project.
